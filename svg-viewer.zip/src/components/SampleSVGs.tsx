import React from 'react';
import { useState } from 'react';

interface SampleSVGsProps {
  onSelectSample: (svgCode: string) => void;
}

const samples = [];

const SampleSVGs: React.FC<SampleSVGsProps> = ({ onSelectSample }) => {
  return null;
};

export default SampleSVGs; 