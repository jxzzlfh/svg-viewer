# New SVG Viewer
一个界面清爽，功能齐全的 SVG 预览网站

网站地址：https://new-svg-viewer.19921014.xyz/

## 特性

- 一键粘贴SVG代码或上传SVG文件
- SVG实时预览
- 一键将SVG导出为PNG、JPEG或SVG，复制到剪贴板
- SVG代码的语法高亮
- 界面干净，纯免费，无广告

![PixPin_2025-02-26_17-32-26](https://github.com/user-attachments/assets/b68058b6-49ab-46cd-b3f1-df979d9aeb96)
